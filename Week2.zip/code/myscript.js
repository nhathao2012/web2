function text(){
	this.innerHTML ="goodbye matt";
}
document.getElementById("mytext").addEventListener("click", text);


